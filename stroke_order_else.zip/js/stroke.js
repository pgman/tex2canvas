/**
 * 3次ベジェ曲線群の静的クラス
 */
const Stroke = (() => {
	
	const 

	/**
	 * 3次ベジェ曲線群描画
	 * @param {CanvasRenderingContext2D} [ctx] - 2Dレンダリングコンテキスト
	 * @param {array} [curves] - 制御点
	 */
	_draw = (ctx, curves) => {
		
	}	

	return {
		draw: _draw,
	};

})();