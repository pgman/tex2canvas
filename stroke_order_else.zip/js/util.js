const Util = (() => {
	
	const 

	/**
	 * 2点間の距離を求める
	 * @param {object} [pos0] - 線分の始点
	 * @param {object} [pos1] - 線分の終点
	 * @return {number} 2点間の距離を返す
	 */
	_distance = (pos0, pos1) => {
		return Math.sqrt(Math.pow(pos0.x - pos1.x, 2) + Math.pow(pos0.y - pos1.y, 2));
	},

	/**
	 * 線形補間する
	 * @param {object} [pos0] - 線分の始点
	 * @param {object} [pos1] - 線分の終点
	 * @param {number} [t] - 補間パラメータ
	 * @return {object} 線形補間された座標を返す
	 */
	_linearInterpolation = (pos0, pos1, t) => {
		return { 
			x: (1 - t) * pos0.x + t * pos1.x,
			y: (1 - t) * pos0.y + t * pos1.y
		};
	},

	/**
	 * canvasを作成する
	 * @param {number} [width] - 幅
	 * @param {number} [width] - 高さ
	 * @return {object} canvasを返す
	 */
	_createCanvas = (width, height) => {
		const canvas = document.createElement('canvas');
		canvas.width = width;
		canvas.height = height;
		return canvas;
	},

	_clearCanvas = (ctx) => {
		ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);	// クリア
	},

	/**
	 * 線分を描画する
	 * @param {object} [pos0] - 線分の始点座標
	 * @param {object} [pos1] - 線分の終点座標
	 */
	_drawLine = (ctx, pos0, pos1) => {
		ctx.beginPath();
		ctx.moveTo(pos0.x, pos0.y);
		ctx.lineTo(pos1.x, pos1.y);
		ctx.stroke();
	},	

	/**
	 * 点配列を拡大する
	 * @param {array} [curves] - 点群
	 * @param {number} [rate] - 拡大率
	 * @return {array} 拡大された点群
	 */
	_zoomCurves = (curves, rate) => {
		return curves.map(array => 
			array.map(inarray => 
				inarray.map(pos => {
					return { x: pos.x * rate, y: pos.y * rate };
				})
			)			
		);
	},

	_isPosInMinMax = (pos, min, max) => {
		if(min.x <= pos.x && pos.x <= max.x
		&& min.y <= pos.y && pos.y <= max.y) {
			return true;
		} else {
			return false;
		}
	},

	/**
	 * 文字列を置換する
	 * @param {string} [expression] - 置換対象文字列
	 * @param {string} [org] - 置換前の文字列
	 * @param {string} [dest] - 置換後の文字列
	 * @return {string} 置換済み文字列
	 */
	_replaceAll = (expression, org, dest) => {
	    return expression.split(org).join(dest);
	};


	return {
		distance: _distance,
		linearInterpolation: _linearInterpolation,
		createCanvas: _createCanvas,
		clearCanvas: _clearCanvas,
		drawLine: _drawLine,
		zoomCurves: _zoomCurves,
		isPosInMinMax: _isPosInMinMax,
		replaceAll: _replaceAll
	};

})();