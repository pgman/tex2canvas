// 定数
const Define = {
	DEBUG: false,									// デバッグ時は true にする
	ORIGINAL_SVG_SIZE: 109,							// オリジナルのSVGのサイズ(109x109)
	ZOOM_RATE: 3,									// 拡大率(整数で指定 - 小数点でもいけるけど念のため整数にしておく)
	INIT_TEXT: '竜',									// 初期表示の文字
	KANJI_SVG_FOLDER: 'kanjivg-master\\kanji\\',	// svgファイルの存在するパス
	SVG_FILE_NAME_LENGTH: 5,						// svgファイル名の長さ
	DECIMAL_NUMBER: 16,								// 16進数
	BASE_WIDTH: 3,									// 基本の太さ
	NO_GET_ORDER: '書き順が取得できませんでした',			// 書き順取得エラーメッセージ(kanzivgに指定の漢字がない場合など用)
	NO_INPUT: '文字が入力されていません',					// 文字が入力されていません
	STROKE_NUMBER: '現在の画数: ',					// 現在アニメーションしている画数
	HEXADECIMAL: '16進数: ',							// 16進数
	GRID_COLOR: 'rgb(128, 128, 128)',				// グリッドの色
};