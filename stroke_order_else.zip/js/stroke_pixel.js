const StrokePixel = (() => {
	
	const 

	/**
	 * ピクセルデータを取得する
	 * @param {array} [strokes] - 曲線群
	 * @return {object} 
	 */
	_getPixelData = (strokes, rate, lineWidth) => {

		console.time('_getPixelData');
		
		const size = Define.ORIGINAL_SVG_SIZE * Define.ZOOM_RATE,
			ctx = Util.createCanvas(size, size).getContext('2d'),
			zoomed = Util.zoomCurves(strokes, rate);
			ret = [];

		ctx.lineCap = 'round';			// 「丸いラインキャップ」の場合
		ctx.lineWidth = lineWidth; 		// 線の幅
		
		// 1画ごと描画して、書かれたピクセルを取得する		
		zoomed.forEach(stroke => {
			
			Util.clearCanvas(ctx);	// クリアする
			
			// 画を描画
			stroke.forEach(curve => {
				CubicBezier.draw(ctx, curve);	
			});		

			ret.push(_getPixels(ctx));	// ピクセルデータを取得
		});

		console.timeEnd('_getPixelData'); // ここで計測時間が出力されます。

		return ret;
	},

	/**
	 * ピクセルデータを取得する
	 * @param {} [ctx] - 曲線群
	 * @return {object} 
	 */
	_getPixels = ctx => {

		// 画像のバッファを取得(バッファはimageData.dataである)
    	const imageData = ctx.getImageData(0, 0, ctx.canvas.width, ctx.canvas.height),
    		data = imageData.data,
    		width = ctx.canvas.width,
    		pixels = [];

    	let minX = width, maxX = 0, minY = width, maxY = 0;

    	for(let i = 0; i < data.length; i += 4) {
    		const a = data[i + 3];	// rgba の a を取得
    		if(a === 255) {// a が 255 => 描画されている
    			const x = (i / 4) % width,			// x値
    				y = parseInt((i / 4) / width);	// y値
    			
    			// minX, maxX, minY, maxY の更新
    			if(x < minX) { minX = x; }
    			else if(x > maxX) { maxX = x; }
    			if(y < minY) { minY = y; }
    			else if(y > maxY) { maxY = y; }
    			
    			// x, y の値を格納
    			pixels.push({ x: x, y: y });
    		}
    	}
    	return { 
    		pixels: pixels, 
    		min: { x: minX, y: minY },
    		max: { x: maxX, y: maxY },
    	};
	},
	/**
	 * 何画目か調べる
	 * @param  {[type]}
	 * @param  {[type]}
	 * @param  {[type]}
	 * @return {[type]} 含まれる画数(含まれない場合は -1 を返す)
	 */
	_getStrokeIndex = (pixelData, x, y) => {
		const pos = { x: x, y: y };
		let ret = -1;

		// 画毎に指定座標が含まれるか調べる。複数の画に含まれる場合は、後勝ちとする
		pixelData.forEach((data, i) => {
			// 矩形内に含まれるか調べる
			if(!Util.isPosInMinMax(pos, data.min, data.max)) {
				return;
			}
			// 画のピクセル毎に一致するか調べる
			if(data.pixels.some(p => p.x === x && p.y === y)) {
				ret = i;
			}
		});

		// 含まれる画数を返す(含まれない場合は -1 を返す)
		return ret;
	};

	return {
		getPixelData: _getPixelData,
		getPixels: _getPixels,
		getStrokeIndex: _getStrokeIndex
	};

})();