/*
[bug]
・"備"がエラーが出てしまう 
   -> プロパティ内に半角スペースがあるのが原因かな？
   -> 半角スペースを削除したがダメ
   -> m(小文字)の処理がうまくできていない感じがする
・アニメーションの種別を変更するとタブが変わってしまう
[memo]
・「どこが塗られたか」ロジックで書き順チェックを行う
・曲線ごとではなく、曲線群毎に長さで分割する -> やや面倒だがやる -> stroke.jsに定義する
・文字色指定 -> easy
・太さ指定 -> easy
・グリッドの表示の有無を指定させる -> easy
・グリッドの区切り数を指定可能にする -> easy
・アニメーションタブが非表示の場合、タイマーを止める -> うまいことやる
・検索後の処理 - 入力時に複数文字なら文字ごとにボタンを表示し、ユーザーに選択させる -> easy
・部首検索、 -> svgに部首的なプロパティがあるが信用してよいものか。他サイトから吸い上げることも可能
・画数検索 -> 全てのSVGファイルを読み込むことで取得可能。他サイトから吸い上げることも可能
・あいうえお検索("あ"を押したら読みがあで始まる漢字が表示される) -> 読みはどうやって取得するのか。他サイトから吸い上げることも可能
・漢字検定検索 -> 最悪他サイトから吸い上げる
・修学年検索 -> 最悪他サイトから吸い上げる
・https://kakijun.jpにあって、kanjivgに無い漢字がある(麤)
・kanjivgに定義されている漢字を抜き出す
  --> フォルダ内のファイルを抽出する
・16進数コードから漢字に変換するプログラムを作成する
  --> 参考: http://d.hatena.ne.jp/yasuhallabo/20140211/1392131668
*/

/*
作業内容
2018/10/01: 
・define.jsを作成する
・グリッド対応
・画毎に塗りつぶしているピクセル情報を取得する -> stroke_pixel.js に定義する
・呼び名を決める 
  1個の3次ベジェ曲線 -> curve
  複数の3次ベジェ曲線からなる曲線群 -> stroke
  1つの文字を表す複数の曲線群 -> strokes
・画数マウスホバー対応 -> mousemoveで実行する。選択画数が変わらないときは、再描画しない。
                   min,maxを利用するなどして、処理速度を上げる必要がある。おそらく時間はかからないため、UIスレッド処理を行う。                   
　　　　　　　　　　　スマホはtouchdown,pointerdownで判定する必要があるかも
*/

const Main = (() => {	
	
	let 
	_strokes = null,								// 曲線群
	_anims = { cnt: 0, intervalId: -1 },
	_selectedWord = '',								// 選択中の文字
	_pixelData = null,								// 文字の塗りつぶされるピクセル情報
	_hovered = -1,									// ホバーされた画数
	_animCtx, _hoverCtx, _workCanvas, _baseCtx, _writtenCtx, _currentCtx, 
	_lastPos = null,
	_inputs = [];

	const
	// 初期化
	_init = () => {

		let canvas;

		const size = Define.ORIGINAL_SVG_SIZE * Define.ZOOM_RATE;

		$('#stroke-count-anim').html(Define.STROKE_NUMBER + '-');

		// 拡大率を反映
		$('#svg-img').css({ width: size + 'px' });
		$('#kanji-hover, #kanji-canvas, #kanji-base, #kanji-written, #kanji-current').prop({ 
			width: size,
			height: size 
		});
		$('#canvas-area').css({ 
			width: size,
			height: size 
		});

		_workCanvas = Util.createCanvas(size, size);
		//_workCtx = canvas.getContext('2d');
		_hoverCtx = $('#kanji-hover')[0].getContext('2d');
		_animCtx = $('#kanji-canvas')[0].getContext('2d');		
		_baseCtx = $('#kanji-base')[0].getContext('2d');
		_writtenCtx = $('#kanji-written')[0].getContext('2d');
		_currentCtx = $('#kanji-current')[0].getContext('2d');

		$('#kanji-text').val(Define.INIT_TEXT);
		
		// イベントハンドラを定義
		_attachEvents();

		$('#decide-button').click();
	},

	_readSvg = (code) => {
		return fetch(Define.KANJI_SVG_FOLDER + code + '.svg')
		.then(e => { 
			if(e.ok) { return e.text(); }
			throw new Error(Define.NO_GET_ORDER);			
		})
		.then(xml => {
			$('#svg-img, #kanji-hover, #kanji-canvas').show();
			_strokes = ParseSvg.parse(xml);
			console.log(_strokes);
			// ホバーを描画
			$('#all-stroke-count-hover').html('総画数: ' + _strokes.length);
			$('#stroke-count-hover').html('現在の画数: ' + '-');

			_pixelData = StrokePixel.getPixelData(_strokes, Define.ZOOM_RATE, Define.ZOOM_RATE * Define.BASE_WIDTH);

			$('#all-stroke-count-anim').html('総画数: ' + _strokes.length);
			$('#stroke-count-anim').html('現在の画数: ' + '-');
			const zoomed = Util.zoomCurves(_strokes, Define.ZOOM_RATE);
			_clearCanvas(_hoverCtx);	
			_gridCanvas(_hoverCtx, 4, 1, Define.GRID_COLOR);					
			_updateCanvas(_hoverCtx, zoomed, Define.ZOOM_RATE * Define.BASE_WIDTH, 'rgb(0, 0, 0)');

			_clearCanvas(_baseCtx);	
			_updateCanvas(_baseCtx, zoomed, Define.ZOOM_RATE * Define.BASE_WIDTH, 'rgb(200, 200, 200)');
		})
		.catch(function(error) {
			_strokes = null;
			_clearCanvas(_hoverCtx);
			_clearCanvas(_animCtx);
			$('#svg-img, #kanji-hover, #kanji-canvas').hide();
			$('#stroke-count-anim').html('-');
			// タイマーを止める
			if(_anims.intervalId !== -1) {
				clearInterval(_anims.intervalId);
				_anims.intervalId = -1;
			}
			$('#result').html('-');
			$('#error-message').html(error.message);
			console.log('There has been a problem with your fetch operation: ', error.message);
		});
	},

	// イベントハンドラを定義
	_attachEvents = () => {
		$( "#tabs" ).tabs();
		$('#decide-button').click(() => {
			let text = $('#kanji-text').val();
			if(text.length <= 0) {// 文字が入力されていない
				$('#error-message').html(Define.NO_INPUT);
				return;
			} else {// 文字が入力されている
				$('#error-message').html('');
				text = text.substring(0, 1).trim(); // 1文字にする				
			}
			// 16進数に変換
			const code = _getCharCode(text);
			// コード表示
			$('#result').html(Define.HEXADECIMAL + code);
			// img 更新
			$('#svg-img').prop({ src: Define.KANJI_SVG_FOLDER + code + '.svg' });
			// 選択文字表示
			$('#current-kanji').html(text);

			// svg読み込み
			_readSvg(code)
			.then(() => {

				// タイマーを止める
				if(_anims.intervalId !== -1) {
					clearInterval(_anims.intervalId);
					_anims.intervalId = -1;
				}
				if(!_strokes) { return; }

				$('#tabs').tabs({ active: 4, });

				_anims.cnt = 0;
				_anims.strokeCnt = 0;		// 何画目か ex. 2 -> 3画目
				_anims.strokeFrame = 0;
				_anims.waitFlag = true;
				_anims.waitCnt = 0;
				_anims.waitMaxCnt = parseInt($('#step-interval').val(), 10);
				_anims.speed = parseInt($('#anim-speed').val(), 10);	
				_anims.fps = parseInt($('#anim-fps').val(), 10);	
				_anims.play = $('#anim-play').val();
				_anims.stopFlag = false;			

				_anims.intervalId = setInterval(() => {
					if(_anims.stopFlag) {
						return;
					}
					if(_anims.waitFlag) {
						_anims.waitCnt++;
						if(_anims.waitCnt >= _anims.waitMaxCnt) {
							_anims.waitFlag = false;
							$('#stroke-count-anim').html(Define.STROKE_NUMBER + (_anims.strokeCnt + 1));
						}
						return;
					}
					const dones = [];
					for(let i = 0; i < _anims.strokeCnt % _strokes.length; i += 1) {
						dones.push(_strokes[i]);
					}

					let tsCnt = 0;
					const currentCurve = [];
					for(let i = 0; i < _strokes[_anims.strokeCnt].length; i += 1) {
						let ts = CubicBezier.divideByLength(_strokes[_anims.strokeCnt][i], 
						_anims.speed);	
						if(tsCnt + ts.length > _anims.strokeFrame) {
							currentCurve.push(CubicBezier.tranform(_strokes[_anims.strokeCnt][i], ts[_anims.strokeFrame - tsCnt]));
							tsCnt += ts.length;
							break;
						} else {
							currentCurve.push(_strokes[_anims.strokeCnt][i]);
						}
						tsCnt += ts.length;
					}	

					dones.push(currentCurve);

					tsCnt = 0;
					for(let i = 0; i < _strokes[_anims.strokeCnt].length; i += 1) {
						let ts = CubicBezier.divideByLength(_strokes[_anims.strokeCnt][i], 
						_anims.speed);	
						tsCnt += ts.length;
					}
					_anims.strokeFrame++;
					if(_anims.strokeFrame >= tsCnt) {
						_anims.strokeCnt++;
						_anims.strokeFrame = 0;
						_anims.waitFlag = true;
						_anims.waitCnt = 0;
						if(_anims.strokeCnt >= _strokes.length) {
							_anims.strokeCnt = 0;
						}
						if(_anims.play === 'step') {// step
							_anims.stopFlag = true;
						}
					}
					const zoomed = Util.zoomCurves(dones, Define.ZOOM_RATE);
					_clearCanvas(_animCtx);	
					_gridCanvas(_animCtx, 4, 1, Define.GRID_COLOR);				
					_updateCanvas(_animCtx, zoomed, Define.ZOOM_RATE * Define.BASE_WIDTH, 'rgb(0, 0, 0)');
				}, 1000 / _anims.fps);				
			});
		});

		$('#anim-play').change(() => {
			_anims.play = $('#anim-play').val();
			if(_anims.play === 'step') {// step
				$('#step-button').show();
			} else {// loop
				$('#step-button').hide();
				_anims.stopFlag = false;
			}
		});

		$('#step-button').click(() => {
			_anims.stopFlag = false;
		});

		$('#anim-speed, #step-interval, #anim-fps').change(() => {
			$('#decide-button').click();
		});

		$('#kanji-text').on('keydown', e => {
			if(e.keyCode === 13) { // Enterキー
				$('#decide-button').click();
			}
		});

		$('#clear-button').click(() => {
			$('#kanji-text').val('').focus();
		});

		$('#kanji-hover').mousemove(e => {
			if(!_pixelData) { return; }
			console.time('getStrokeIndex');
			const index = StrokePixel.getStrokeIndex(_pixelData, e.offsetX, e.offsetY);
			console.timeEnd('getStrokeIndex'); // ここで計測時間が出力されます。
			const zoomed = Util.zoomCurves(_strokes, Define.ZOOM_RATE);			
			
			if(_hovered !== index) {// 直前の描画と異なる
				// 再描画する
				_clearCanvas(_hoverCtx);	
				_gridCanvas(_hoverCtx, 4, 1, Define.GRID_COLOR);					
				_updateCanvas(_hoverCtx, zoomed, Define.ZOOM_RATE * Define.BASE_WIDTH, 'rgb(0, 0, 0)');
				if(index >= 0) {// 現在ある画の上にカーソルが存在する
					_updateCanvas(_hoverCtx, [zoomed[index]], Define.ZOOM_RATE * 5, 'rgb(255, 0, 0)');
					$('#stroke-count-hover').html('現在の画数: ' + (index + 1));
				} else {
					$('#stroke-count-hover').html('現在の画数: ' + '-');
				}			
			}

			_hovered = index;	// 記憶			
		});

		$('#kanji-current').mousedown(e => {
			_lastPos = { x: e.offsetX, y: e.offsetY };
			_inputs.push([_lastPos]);
		});
		$('#kanji-current').mouseup(e => {
			_lastPos = null;

			// 下に書く
			const temp = StrokePixel.getPixels(_currentCtx);
			console.log(temp);

			// 画数分の配列を作成
			// カウンタを0にリセット
			let counts = [];
			for(let i = 0; i < _strokes.length; i += 1) {
				counts[i] = 0;
			}
			
			console.time('画数判定');
			temp.pixels.forEach(pixel => {
				const index = StrokePixel.getStrokeIndex(_pixelData, pixel.x, pixel.y);
				if(index >= 0) {
					counts[index]++;
				}
			});
			console.timeEnd('画数判定');

			// 一番大きい画数を表示する
			const maxIndex = counts.indexOf(Math.max.apply(null, counts));

			if(_inputs.length - 1 === maxIndex) {
				console.log('ok');
			} else {
				console.log('ng');
			}			

			_clearCanvas(_currentCtx);

			_writtenCtx.lineCap = 'round';			// 「丸いラインキャップ」の場合
			_writtenCtx.lineWidth = Define.ZOOM_RATE * Define.BASE_WIDTH; 		// 線の幅
			
			for(let i = 0; i < _inputs[_inputs.length - 1].length - 1; i += 1) {
				Util.drawLine(_writtenCtx, _inputs[_inputs.length - 1][i], _inputs[_inputs.length - 1][i + 1]);
			}

			// text to be sent
			var text = {
			  'app_version' : 0.4,
			  'api_level' : '537.36',
			  'device' : window.navigator.userAgent,
			  'input_type' : 0, // ?
			  'options' : 'enable_pre_space', // ?
			  'requests' : [ {
			    'writing_guide' : {
			      'writing_area_width' : 200,//Define.ORIGINAL_SVG_SIZE * Define.ZOOM_RATE, // canvas width
			      'writing_area_height' : 200,//Define.ORIGINAL_SVG_SIZE * Define.ZOOM_RATE, // canvas height
			    },
			    'pre_context' : '', // confirmed preceding chars
			    'max_num_results' : 1,
			    'max_completions' : 0,
			    'ink' : []
			  } ]
			};

			// 変換
			const points = _inputs.map((array, i) => { 
				return [array.map(pos => pos.x), array.map(pos => pos.y), [i * 2, i * 2 + 1] ]
			});
			console.log(points);
			console.log(_inputs);

			// convert points to ink
text.requests[0].ink = [
  [[0,100],[200,100]],
];
text.requests[0].ink = points;

			// send ajax request
			$.ajax({
			  url : 'https://inputtools.google.com/request?itc=ja-t-i0-handwrit&amp;app=demopage',
			  method : 'POST',
			  contentType : 'application/json',
			  data : JSON.stringify(text),
			  dataType : 'json',
			}).done(function(json) {
			  console.log(json[1][0][1]);
			});
 
 
		});
		$('#kanji-current').mouseout(e => {
			_lastPos = null;			
		});
		$('#kanji-current').mousemove(e => {
			if(!_lastPos) { return; }
			let curPos = { x: e.offsetX, y: e.offsetY };
			_currentCtx.lineCap = 'round';			// 「丸いラインキャップ」の場合
			_currentCtx.lineWidth = Define.ZOOM_RATE * Define.BASE_WIDTH; 		// 線の幅
			Util.drawLine(_currentCtx, _lastPos, curPos);
			_lastPos = curPos;
			_inputs[_inputs.length - 1].push(_lastPos);

			// どの画を最も塗りつぶしているか判定

		});
	},

	// 文字の UTF-16 コードを16進数で取得
	_getCharCode = (str) => {
		let ret;
		if(str.length !== 1) { return ''; }
		ret = str.charCodeAt(0).toString(Define.DECIMAL_NUMBER);	// 16進数で取得
		ret = _zeroPadding(ret, Define.SVG_FILE_NAME_LENGTH);	// 0 padding する
		return ret;
	},

	// 0 paddingする
	_zeroPadding = (num, length) => {
    	return ('0000000000' + num).slice(-length);
	},

	_clearCanvas = (ctx) => {
		ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);	// クリア
	},

	// グリッドを描画
	_gridCanvas = (ctx, divide, lineWidth, color) => {

		ctx.lineWidth = lineWidth; 		// 線の幅
		ctx.strokeStyle = color;		// 色設定

		for(let i = 1; i < divide; i += 1) {
			const cur = (ctx.canvas.width / divide) * i
			Util.drawLine(ctx, { x: cur, y: 0 }, { x: cur, y: ctx.canvas.height });	// y軸と平行な線
			Util.drawLine(ctx, { x: 0, y: cur }, { x: ctx.canvas.width, y: cur });	// x軸と平行な線
		}
	},

	// canvasを更新する
	_updateCanvas = (ctx, strokes, lineWidth, color) => {
		let zoomed;

		if(!strokes) { return; }
		
    	ctx.lineCap = 'round';			// 「丸いラインキャップ」の場合
		ctx.lineWidth = lineWidth; 		// 線の幅
		ctx.strokeStyle = color;		// 色設定
		
		strokes.forEach(stroke => {
			stroke.forEach(curve => {
				CubicBezier.draw(ctx, curve);	
			});
		});		
	};

	return {
		init: _init
	};

})();