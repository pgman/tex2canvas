const ParseSvg = (() => {
	
	const 

	/**
	 * SVGファイルを解析する
	 * @param {string} [svg] - svgファイルのテキスト
	 * @return {object} 
	 */
	_parse = (svg) => {
		let parser = new DOMParser();
		let doc = parser.parseFromString(svg, "text/xml");
		let curves = [];
			
		// array like object を array に変換
		const paths = Array.from(doc.children[0].getElementsByTagName('path'));

		// <path>でループ
		paths.forEach(path => {
			let tmp = $(path)[0].outerHTML.substring($(path)[0].outerHTML.indexOf('d="M')).substring('d="'.length);
			tmp = tmp.substring(0, tmp.length - '"/>'.length);
			curves.push(_splitPath(tmp));		
		});		

		return curves;	
	},

	/**
	 * 
	 */
	_splitPath = (path) => {

		const carrays = _analyzePath(Util.replaceAll(path, ' ', ''));

		const ret = [];

		ret[0] = [];
		ret[0].push({ x: carrays[0].values[0], y: carrays[0].values[1] });		

		carrays.forEach((carray, i) => {

			if(i === 0) {
				return;
			} 

			const last = ret[ret.length - 1][ret[ret.length - 1].length - 1];
			if(i >= 2) {
				ret.push([]);
				ret[ret.length - 1].push({ x: last.x, y: last.y });
				if(carray.type === 's' || carray.type === 'S') {
					ret[ret.length - 1].push({ x: last.x, y: last.y });
				}
			}
			carray.values.forEach((c, j) => {
				if(carray.type === 'c' || carray.type === 's') {// c or s
					if(j % 2 === 0) {
						ret[i - 1].push({ x: c + last.x });
					} else {
						ret[i - 1][ret[i - 1].length - 1].y = c + last.y;
					}
				} else if(carray.type === 'C' || carray.type === 'S') {// C or S
					if(j % 2 === 0) {
						ret[i - 1].push({ x: c });
					} else {
						ret[i - 1][ret[i - 1].length - 1].y = c;
					}
				} else {
					throw Error('svgファイルの解析に失敗しました');
				}
			});
		});

		return ret;
	},

	/**
	 * 点配列を拡大する
	 * @param {array} [curves] - 点群
	 * @param {number} [rate] - 拡大率
	 * @return {array} 拡大された点群
	 */
	// path を解析
	_analyzePath = path => {
		// "M51.75,10.5c1.19,1.19,2,3,2,5c0,8.65,0,55.15-0.14,74.75c-0.03,4.19-0.07,7.15-0.11,8.25"
		// を
		/* 
		[ 
			{ 
				type: 'M', array: [ 51.75,10.5 ] 
			},
			{ 
				type: 'c', array: [ 1.19, 1.19, 2, 3, 2, 5 ] 
			},
			{ 
				type: 'c', array: [ 0, 8.65, 0, 55.15, -0.14, 74.75 ] 
			},
			...
		]
		のように分解する
		*/

		const ret = [];

		const p = /[M/m/C/c/S/s]+/g; 
		var splits = path.split(p);
		// splitsの先頭は空配列であるため、配列から削除
		splits.shift();

		var cnt = 0; // 無限ループ検出用カウンタ
		while (result = p.exec(path)) {		

			const tcp = splits[cnt].split(',');
			const curves = [];
			tcp.forEach(tp => {
				const splits = tp.split('-');
				if(splits.length === 1) {
					const val = parseFloat(tp);
					curves.push(val);
				} else if(splits.length >= 2) {
					splits.forEach((sp, spi) => {
						if(sp) {
							let val = parseFloat(sp);
							if(spi >= 1) {
								val *= -1;
							}
							curves.push(val);
						}
					});
				} else {

				}
			});		

			ret.push({
				type: path[result.index],
				values: curves
			});

			if(cnt++ > 10000) { break; }
		 	
		}

		return ret;
	};

	return {
		parse: _parse
	};

})();