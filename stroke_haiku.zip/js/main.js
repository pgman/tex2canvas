const Main = (() => {	

	/*
	背景を黒板にする
	チョークの字を再現する(乱数を固定する必要がある)
	書き終えるタイミングをなるべく揃える
	 */
	
	let 
	_blackBoardImg = null,
	_strokesArray = null,
	_animsArray = null,
	_zoomedArray = null,
	_mainCanvas = null,
	_canvases = [],	// 描画されるcanvas
	_pastes = [],	// 貼り付けられるcanvas
	_moveds = [],	// どのピクセルを動かしたか
	_finished = false,
	_finishedElms = null,
	_drawFrame = 0,
	_strokeInfos = [],
	_curIndex = 0;

	const _word = '七時ごろ屁かと思たらうんこ出た',
		STRING_COLOR = 'rgb(255, 255, 255)',
		ALPHA = 0.6,
		SEED = 'abcde',
		MEAN = 0,
		SD = 0.5,
		ANIM_SPEED = 3;
	
	const
	// 初期化
	_init = () => {

		// 乱数の種を固定
		Math.seedrandom(SEED);

		_mainCanvas = $('#main-canvas')[0];
		
		// width, height は小数点以下は切り捨てられる
		_mainCanvas.width = 720;
		_mainCanvas.height = 800;

		let codes = [];
		for(let i = 0; i < _word.length; i += 1) {
			codes.push(_getCharCode(_word[i]));
			const canvas = Util.createCanvas(Define.ORIGINAL_SVG_SIZE * Define.ZOOM_RATE,
				Define.ORIGINAL_SVG_SIZE * Define.ZOOM_RATE);
			_canvases.push(canvas);
			const paste = Util.createCanvas(Define.ORIGINAL_SVG_SIZE * Define.ZOOM_RATE,
				Define.ORIGINAL_SVG_SIZE * Define.ZOOM_RATE);
			_pastes.push(paste);
			_moveds.push([]);
		}

		// Promise.all用の配列を作成する
		asyncCodes = codes.map(code => _readSvg(code));

		_loadImage('images/black_board.jpg')
		.then(img => {
			_blackBoardImg = img;
		})
		.then(() => {
			return Promise.all(asyncCodes)
		})		
		.then(xmls => {
			_strokesArray = xmls.map(xml => ParseSvg.parse(xml));
			_strokeInfos = _getStrokeInfos(_strokesArray)
			_animsArray = xmls.map((xml, i) => {
				const anims = {
					cnt: 0,
					strokeCnt: 0,	// 何画目か ex. 2 -> 3画目
					strokeFrame: 0,			
				};
				return anims;
			});

			_zoomedArray = xmls.map(xml => null);

			_finishedElms = xmls.map(xml => false);

			_clearCanvas(_mainCanvas);	
			_drawBackgroundCanvas(_mainCanvas, _blackBoardImg);

			setTimeout(() => {
				requestAnimationFrame(_draw);
			}, 1000);
		});		
	},

	_getStrokeInfos = function(strokeArray) {
		let infos = [];

		for(let i = 0; i < _strokesArray.length; i += 1) {
			const strokesInfo = [];
			const strokes = _strokesArray[i];

			for(let j = 0; j < strokes.length; j += 1) {
			 	const stroke = strokes[j];

			 	let tsArray = []
			 	for(let k = 0; k < stroke.length; k += 1) {
			 		const bezier = stroke[k];
			 		let ts = CubicBezier.divideByLength(bezier, ANIM_SPEED);	
			 		tsArray.push(ts);
			 	}	
			 	strokesInfo.push(tsArray); 	
			}
			infos.push(strokesInfo);
		}
		return infos;
	},

	_getBezier = function(infos, count) {
		let curCount;

	},

	_loadImage = function(dataUrl) {
	    return new Promise(function(resolve, reject) {
			var image = new Image();
			image.onload = function() {
				resolve(image);
			};
			image.src = dataUrl;
	    });
	},  

	_readSvg = (code) => {
		return fetch(Define.KANJI_SVG_FOLDER + code + '.svg')
		.then(e => { 
			if(e.ok) { return e.text(); }
			throw new Error(Define.NO_GET_ORDER);			
		})
		.then(xml => {
			return new Promise((resolve, reject) => {
				resolve(xml);
			});			
		})
		.catch(function(error) {
			console.log('There has been a problem with your fetch operation: ', error.message);
		});
	},

	_draw = () => {
		
		// ここから本処理
		_drawFrame++;

		// 少しずつ書いていく
		if(_curIndex >= _word.length) { return; }
		
		const strokes = _strokesArray[_curIndex],
			anims = _animsArray[_curIndex];

		const dones = [];
		for(let j = 0; j < anims.strokeCnt % strokes.length; j += 1) {
			dones.push(strokes[j]);
		}

		let tsCnt = 0;
		const currentCurve = [];
		for(let j = 0; j < strokes[anims.strokeCnt].length; j += 1) {
			let ts = CubicBezier.divideByLength(strokes[anims.strokeCnt][j], 
			ANIM_SPEED);	
			if(tsCnt + ts.length > anims.strokeFrame) {
				currentCurve.push(CubicBezier.tranform(strokes[anims.strokeCnt][j], ts[anims.strokeFrame - tsCnt]));
				tsCnt += ts.length;
				break;
			} else {
				currentCurve.push(strokes[anims.strokeCnt][j]);
			}
			tsCnt += ts.length;
		}	

		dones.push(currentCurve);

		tsCnt = 0;
		for(let j = 0; j < strokes[anims.strokeCnt].length; j += 1) {
			let ts = CubicBezier.divideByLength(strokes[anims.strokeCnt][j], 
			ANIM_SPEED);	
			tsCnt += ts.length;
		}
		const index = _curIndex;
		anims.strokeFrame++;
		if(anims.strokeFrame >= tsCnt) {
			anims.strokeCnt++;
			anims.strokeFrame = 0;
			if(anims.strokeCnt >= strokes.length) {
				anims.strokeCnt = 0;
				_curIndex++;
			}
		}
		const zoomed = Util.zoomCurves(dones, Define.ZOOM_RATE);
		_zoomedArray[index] = zoomed;		

		_clearCanvas(_mainCanvas);	
		_drawBackgroundCanvas(_mainCanvas, _blackBoardImg);
		
		for(let i = 0; i < _strokesArray.length; i += 1) {
			const canvas = _canvases[i];
			_clearCanvas(canvas);
			if(!_zoomedArray[i]) {
				continue;
			}
			_updateCanvas(canvas, _zoomedArray[i], 
				Define.ZOOM_RATE * Define.BASE_WIDTH, 
				STRING_COLOR);

			const paste = _pastes[i];
			const moved = _moveds[i];

			_updatePastes(paste, canvas, moved);

			if(i < 4) {
				_updateMainCanvas(_mainCanvas, paste, 
				ALPHA,
				500, 
				50 + Define.ZOOM_RATE * Define.ORIGINAL_SVG_SIZE * i);
			} else if(i < 10) {
				_updateMainCanvas(_mainCanvas, paste, 
				ALPHA,
				300, 
				50 + Define.ZOOM_RATE * Define.ORIGINAL_SVG_SIZE * (i - 4));
			} else {
				_updateMainCanvas(_mainCanvas, paste, 
				ALPHA,
				100, 
				50 + Define.ZOOM_RATE * Define.ORIGINAL_SVG_SIZE * (i - 10));
			}			
		}
				
		requestAnimationFrame(_draw);
	},

	// 文字の UTF-16 コードを16進数で取得
	_getCharCode = (str) => {
		let ret;
		if(str.length !== 1) { return ''; }
		ret = str.charCodeAt(0).toString(Define.DECIMAL_NUMBER);	// 16進数で取得
		ret = _zeroPadding(ret, Define.SVG_FILE_NAME_LENGTH);	// 0 padding する
		return ret;
	},

	// 0 paddingする
	_zeroPadding = (num, length) => {
    	return ('0000000000' + num).slice(-length);
	},

	_clearCanvas = canvas => {
		const ctx = canvas.getContext('2d');
		ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);	// クリア
	},

	_drawBackgroundCanvas = (canvas, img) => {
		const ctx = canvas.getContext('2d');
		ctx.drawImage(img, 
			0, 0, img.width, img.height,
			0, 0, canvas.width, canvas.height);
	},

	// canvasで塗られている箇所を動かし記憶する
	// ※動かしたピクセルは動かさない
	_updatePastes = (paste, canvas, moved) => {
		
		const ctx = canvas.getContext('2d');

		// imageDataを取得
		const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
		const data = imgData.data;
		const w = canvas.width;
		const h = canvas.height;

		let changed = false;

		let nd, randX, randY;
		let count = 0;

		// 塗られている点を動かす
		for(let y = 0; y < h; y += 1) {
			for(let x = 0; x < w; x += 1) {
				const i = y * w + x;
				// ピクセルのインデックスを求める
				const pi = i * 4;

				// 塗られているか調べる
				if(data[pi + 3] !== 0) {// 塗られている
					if(typeof moved[i] === 'undefined'
					|| (typeof moved[i] !== 'undefined' && moved[i].rgba.a !== 255 && data[pi + 3] === 255) ) {// 処理されていない
						// 乱数を発生させる
						if(++count % 4 === 0) {
							nd = Util.normalDistribution(MEAN, SD);
							randX = Math.round(nd.z1);
							randY = Math.round(nd.z2);
						}

						moved[i] = {
							pos: { 
								x: x + randX, 
								y: y + randY 
							},
							rgba: {
								r: data[pi + 0],
								g: data[pi + 1],
								b: data[pi + 2],
								a: data[pi + 3]
							}
						};

						if(randX || randY) {
							//data[pi + 3] = data[pi + 3] * 0.2;
						}

						changed = true;
					}
				}
			}
		}

		// 変化がないので何もしない
		if(!changed) { return; }

		// imageDataを作成する
		const pasteImgData = new ImageData(w, h);
		const pasteData = pasteImgData.data;

		// pasteに張り付ける
		for(let y = 0; y < h; y += 1) {
			for(let x = 0; x < w; x += 1) {
				const i = y * w + x;
				// ピクセルのインデックスを求める
				const pi = i * 4;

				if(typeof moved[i] !== 'undefined') {// 処理されている
					const mi = moved[i].pos.y * w + moved[i].pos.x;
					// ピクセルのインデックスを求める
					const mpi = mi * 4;

					pasteData[mpi + 0] = moved[i].rgba.r;
					pasteData[mpi + 1] = moved[i].rgba.g;
					pasteData[mpi + 2] = moved[i].rgba.b;
					pasteData[mpi + 3] = moved[i].rgba.a;

					if(pi !== mpi) {
						pasteData[pi + 0] = moved[i].rgba.r;
						pasteData[pi + 1] = moved[i].rgba.g;
						pasteData[pi + 2] = moved[i].rgba.b;
						//const nd = Util.normalDistribution(MEAN, SD);
						pasteData[pi + 3] = moved[i].rgba.a * 0.2;//(0.5 + Math.random() * 0.4);
					}					
				}
			}
		}

		_clearCanvas(paste);
		const pasteCtx = paste.getContext('2d');
		pasteCtx.putImageData(pasteImgData, 0, 0);
		
		// ImageDataを作成する
		function ImageData() {
		    var i = 0;
		    if(arguments[0] instanceof Uint8ClampedArray) {
		        var data = arguments[i++];
		    }
		    var width = arguments[i++];
		    var height = arguments[i];      
		 
		    var canvas = document.createElement('canvas');
		    canvas.width = width;
		    canvas.height = height;
		    var ctx = canvas.getContext('2d');
		    var imageData = ctx.createImageData(width, height);
		    if(data) imageData.data.set(data);
		    return imageData;
		}

	},

	// canvasを更新する
	_updateMainCanvas = (dstCanvas, srcCanvas, alpha, transX, transY) => {
		
		const ctx = dstCanvas.getContext('2d');

		ctx.save();

		ctx.setTransform(1.000, 0, 0, 1.000, transX, transY);
		
    	ctx.globalAlpha = alpha;
		
		ctx.drawImage(srcCanvas, 0, 0);

		ctx.restore();
	},

	// canvasを更新する
	_updateCanvas = (canvas, strokes, lineWidth, color) => {
		const ctx = canvas.getContext('2d');

		ctx.save();

		ctx.imageSmoothingEnabled = false;
    	ctx.lineCap = 'round';			// 「丸いラインキャップ」の場合
		ctx.lineWidth = lineWidth; 		// 線の幅
		ctx.strokeStyle = color;		// 色設定
		
		strokes.forEach(stroke => {
			stroke.forEach(curve => {
				CubicBezier.draw(ctx, curve);	
			});
		});		

		ctx.restore();
	};



	return {
		init: _init
	};

})();